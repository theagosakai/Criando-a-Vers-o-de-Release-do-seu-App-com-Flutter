class Todo {
  int id;
  String descricao;
  Todo({this.id, this.descricao});
}